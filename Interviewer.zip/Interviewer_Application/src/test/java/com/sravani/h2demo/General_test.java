package com.sravani.h2demo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sravani.Interviewer_pac.Interviewer_repo;

@SpringBootTest
class General_test {
	
	
	@Autowired
	Interviewer_repo repo;

	@Test
	public void Course_present() {
		
		System.out.println(repo.findById(1));
		
	}

}
