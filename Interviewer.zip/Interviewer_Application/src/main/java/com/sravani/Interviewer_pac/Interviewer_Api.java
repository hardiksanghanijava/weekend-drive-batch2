package com.sravani.Interviewer_pac;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class Interviewer_Api {
	
	@Autowired
	private Interviewer_repo repo;

	
	@GetMapping("/jpa/interviewer")
	public List<Interviewer> retrieveAllInterviewers() {
		return repo.findAll();
	}

	
	@GetMapping("/jpa/interviewer/{id}")
	public Optional<Interviewer> retrieveInterviewer(@PathVariable int id) {
		Optional<Interviewer> interviewer = repo.findById(id);
		
		//if(!user.isPresent())
			//throw new UserNotFoundException("id-"+ id);
		return interviewer;
	}
	
	@DeleteMapping("/jpa/interviewer/{id}")
	public void delete_Interviewer(@PathVariable int id) {
		repo.deleteById(id);
		
		//if(user==null)
			//throw new UserNotFoundException("id-"+ id);		
	}
	
	@PostMapping("/jpa/interviewer_save")
	public void Create_Interviewer( @RequestBody Interviewer user) {
		repo.save(user);
	}
	
	@PutMapping("/jpa/interviewer_update")
	public Interviewer Update(@RequestBody Interviewer user) {
		return repo.save(user);
	}
		
		
		
	
	

}
