package com.sravani.Interviewer_pac;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


@Repository
public interface Interviewer_repo extends JpaRepository<Interviewer , Integer>{
	
	@Modifying
	@Query("update Interviewer set name = :up_name where id = :up_id")
	void update(int up_id , String up_name);
	
	

}
