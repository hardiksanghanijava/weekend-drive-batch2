package com.sravani.Interviewer_pac;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.Id;




@Entity
public class Interviewer {

	@Id
	private int id;

	@Column(nullable = false)
	private String name;
	protected Interviewer() {
	}

	public Interviewer(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
	

	

	public int getId() {
		return id;
	}

	@Override
	public String toString() {
		return String.format("Course[%s]", name);
	}
	
}
